"""AI Router -- KiCad PCM entry point.

KiCad loads this file when it discovers the package; importing the
bundled ai_router package (installed beside this file) registers
the ActionPlugin. See build_package.py (#156).
"""
import os, sys
_here = os.path.dirname(os.path.abspath(__file__))
if _here not in sys.path:
    sys.path.insert(0, _here)
try:
    import ai_router  # noqa: F401  (importing registers the plugin)
except Exception as _e:
    print('ai_router: PCM entry point failed to load the bundled plugin (%r)' % (_e,))
